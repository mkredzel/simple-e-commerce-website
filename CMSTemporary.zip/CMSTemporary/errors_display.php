<?php

$manager     =   new MongoDB\Driver\Manager("mongodb://localhost:27017");

/* success, error messages to be displayed */

 $messages = array(
  1=>'Record deleted successfully',
  2=>'Error occurred. Please try again',
  3=>'Record saved successfully',
  4=>'Record updated successfully',
  5=>'There are some fields that are mandatory',
  6=>'Record saved successfully but the image path is missing, you can update it later',
  7=>'Request unfulfilled, enter Name and Country of the product you want to edit');
