<?php

    require_once('errors_display.php');

  $p_name = '';
  $p_type = '';
  $p_price = 0;
  $p_country = '';
  $p_abv = 0;
  $p_description = '';
  $p_image = '';
  $p_stock_count = 0;

  if(isset($_POST['btn'])){
      $p_name = $_POST['name'];
      $p_type = $_POST['type'];
      $p_price = $_POST['price'];
      $p_country = $_POST['country'];
      $p_abv = $_POST['abv'];
      $p_description = $_POST['description'];
      $p_image = $_POST['image'];
      $p_stock_count = $_POST['stock_count'];
      if(!$p_name ||
         !$p_type ||
         !$price ||
         !$p_country ||
         !$p_abv
          ){

        $flag = 5;

      }else if (!$p_image ){

           $insRec = new MongoDB\Driver\BulkWrite;
           $insRec->insert(['name' =>$p_name,
           'type' =>$p_type,
           'price'=>$p_price,
           'country'=>$p_country,
           'abv'=>$p_abv,
           'description'=>$p_description,
           'stock_count'=>$p_stock_count,
         ]);

           $writeConcern = new MongoDB\Driver\WriteConcern(MongoDB\Driver\WriteConcern::MAJORITY, 1000);

             $result = $manager->executeBulkWrite('onlinestore.products', $insRec, $writeConcern);
          if($result->getInsertedCount()){
            $flag = 6;
          }else{
            $flag = 2;
          }
      }

      else {

           $insRec       = new MongoDB\Driver\BulkWrite;
           $insRec->insert(['name' =>$p_name,
           'type' =>$p_type,
           'price'=>$p_price,
           'country'=>$p_country,
           'abv'=>$p_abv,
           'description'=>$p_description,
           'image'=>$p_image,
           'stock_count'=>$p_stock_count,
         ]);

           $writeConcern = new MongoDB\Driver\WriteConcern(MongoDB\Driver\WriteConcern::MAJORITY, 1000);

             $result       = $manager->executeBulkWrite('Ecommerce.products', $insRec, $writeConcern);
          if($result->getInsertedCount()){
            $flag = 3;
          }else{
            $flag = 2;
          }
      }
  }
  header("Location: index.php?flag=$flag");
  exit;
